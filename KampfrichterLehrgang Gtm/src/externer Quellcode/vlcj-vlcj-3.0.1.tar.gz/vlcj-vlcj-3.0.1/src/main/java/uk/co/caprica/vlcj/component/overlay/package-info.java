/**
 * Provides higher-level components used to create overlays for use with
 * embedded media players.
 */
package uk.co.caprica.vlcj.component.overlay;
