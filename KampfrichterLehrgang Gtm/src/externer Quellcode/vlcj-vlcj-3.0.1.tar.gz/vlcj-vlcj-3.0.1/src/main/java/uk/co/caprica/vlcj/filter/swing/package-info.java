/**
 * Implementation of a Swing filter that could be used to create an open media
 * dialog box for all of the media file types supported by vlc.
 */
package uk.co.caprica.vlcj.filter.swing;
