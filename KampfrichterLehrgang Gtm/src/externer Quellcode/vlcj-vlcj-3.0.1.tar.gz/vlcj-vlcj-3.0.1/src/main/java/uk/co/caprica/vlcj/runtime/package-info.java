/**
 * Provides various operating-system dependent run-time utility classes.
 */
package uk.co.caprica.vlcj.runtime;
