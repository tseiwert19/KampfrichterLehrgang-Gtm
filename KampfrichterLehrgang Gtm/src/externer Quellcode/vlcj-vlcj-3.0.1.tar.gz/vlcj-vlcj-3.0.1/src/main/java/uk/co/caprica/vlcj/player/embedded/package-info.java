/**
 * Provides the classes necessary to support the embedding of native media
 * player video output in Swing/AWT user interface components.
 */
package uk.co.caprica.vlcj.player.embedded;
