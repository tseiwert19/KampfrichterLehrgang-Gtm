/**
 * Provides X-Windows-specific support for user interface components that embed
 * native video.
 */
package uk.co.caprica.vlcj.player.embedded.x;
