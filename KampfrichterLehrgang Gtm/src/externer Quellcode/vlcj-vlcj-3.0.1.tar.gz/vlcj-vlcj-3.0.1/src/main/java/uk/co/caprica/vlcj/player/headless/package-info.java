/**
 * Provides the classes necessary to support the use of native media players
 * that do not render video output locally - for example streaming servers.
 */
package uk.co.caprica.vlcj.player.headless;
