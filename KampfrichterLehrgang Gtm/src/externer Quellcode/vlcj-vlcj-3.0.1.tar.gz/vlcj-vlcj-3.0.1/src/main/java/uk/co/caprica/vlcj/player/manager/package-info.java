/**
 * Provides the classes necessary to use the native Media Manager.
 */
package uk.co.caprica.vlcj.player.manager;
